/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "___PROJECTNAMEASIDENTIFIER___ModuleAssets.h"

extern NSData* filterData(NSString* thedata, NSString* identifier);

@implementation ___PROJECTNAMEASIDENTIFIER___ModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
