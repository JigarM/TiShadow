# -*- coding: utf-8 -*-
# URI package
# Author: Joshua E Cook <jcook at particleweb dot com>

import uri
import authority
import location
import path
import filename
import query
