#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
import os

print "no"  		#custom hw

# print "96"			#ram
# print "yes"			#touchscreen
# print "yes"			#trackball
# print "yes"			#keyboard
# print "yes"			#dpad
# print "yes"			#gsm
# print "yes"			#camera
# print "640"			#max h
# print "480"			#max v
# print "yes"			#gps
# print "yes"			#battery
# print "yes"			#accel
# print "yes"			#audio in
# print "yes"			#audio out
# print "yes"			#sd
# print "yes"			#disk cache
# print "66"			#disk cache size
