package ${config['appid']};

import ti.modules.titanium.android.TiJSActivity;

public final class ${activity['classname']} extends TiJSActivity {
	public ${activity['classname']}() {
		super("${activity['url']}");
	}
}
